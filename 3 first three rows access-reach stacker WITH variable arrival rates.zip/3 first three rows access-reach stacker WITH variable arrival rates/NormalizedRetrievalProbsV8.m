
function [NormalizedRetrievalProbs, steadyStateProbabilities] = NormalizedRetrievalProbsV8(TransitionMatrix, RetrievalArrivalRateColumnArray)

% https://www.mathworks.com/matlabcentral/answers/391167-steady-state-and-transition-probablities-from-markov-chain

                    %extra webpage https://nicolewhite.github.io/2014/06/10/steady-state-transition-matrix.html


% eig(P');
% 
% [V,D] = eig(P');
% p = V(:,1)';
% p = p./sum(p);
    

        % %https://www.mathworks.com/matlabcentral/answers/59123-steady-state-probability-calculation-solve-simultaneous-eq-with-33-unknowns
        [V,D] = eig(TransitionMatrix'); % Find eigenvalues and left eigenvectors of A
         [~,ix] = min(abs(diag(D)-1)); % Locate an eigenvalue which equals 1
         steadyStateProbabilities = V(:,ix)' ;% The corresponding row of V' will be a solution
         
         steadyStateProbabilities = steadyStateProbabilities/sum(steadyStateProbabilities); % Adjust it to have a sum of 1
         
         % below added to normalize all steady state probabilities after
         % considering that there is %50 chnace that every state has a
         % retrieval request chance except empty and full bay
         % configurations
         indexForFullConfi= length(steadyStateProbabilities); % finds the index for full bay configuration
         
         columnYforEmpty= steadyStateProbabilities(1)*0;                 % calculates the probability of retrieval chance when the bay configuration is empty. it is 0
         columnYforFull= steadyStateProbabilities(indexForFullConfi)*1;  % calculates the probability of retrieval chance when the bay configuration is full. it is 1
         
         % START here is added for variable Retieval rate modification
         [~, LenghtOfColumnY] = size(steadyStateProbabilities);  % finds the size to make empty "Column Y" array 
         columnY=zeros(1, LenghtOfColumnY); %creates empty "Column Y" array
         for Index=1:LenghtOfColumnY
         columnY(Index) = steadyStateProbabilities(Index) * RetrievalArrivalRateColumnArray(Index,1); %(1-ArrivalRate); % this row multiplies all steady state probabilities by retrieval probabilities to find each states retrieval probabilities because relocations only exists when there is a retrieval.
         end
         % END here is added for variable Retieval rate modification
         
         columnY(1) =columnYforEmpty;                          % just replaces the calculated probability above for empty bay exception which is 0
         columnY(indexForFullConfi) = columnYforFull;          % just replaces the calculated probability above for full bay exception which is 1
        % columnY   % columny refers an array stores the every
        % configurations retrieval chance
        
        NormalizedRetrievalProbs = columnY / sum(columnY); % this row just normalized the columnY values to get total probability of 1 since we multiplied all values by 0.5 to get retrieval probabilities above
        % columnZ values are normalized values .ColumnZ values refer the
        % excel File "RevisedResultsMonteCarloVSmarkov" files column z
        % values
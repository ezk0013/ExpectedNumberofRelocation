clear
clc
%///////////////enter the paramaters 
%ArrivalRates = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];      % new added for various arrival rates
                        
%for indexx= 6% 1:length(ArrivalRates)             % new added for various arrival rates
%indexx= 6;    
%ArrivalRate=ArrivalRates(indexx);        % new added for various arrival rates
highestRow=6;   %highestRow=10; 
highestTier=4;   %highestTier=8;
%///////////
totalNumbersOfRehandlesTable=zeros(highestRow+1,highestTier+1);
RunTimeTable=zeros(highestRow+1,highestTier+1);
tic
index=1;
for rows = 1:highestRow 
    for tiers = 1:highestTier
        rows
        tiers      
        configurations = configurationsConstructionV4(rows, tiers) ;           % calls the FUNCTION "configurationsConstruction" which constructs the "configurations" matrix
  
      %RetrievalRate and ArrivalRate calculation START
       [yy,xx] = size(configurations);
            BayCapacity=rows*tiers;
            RetrievalRate=0;
            ArrivalRate=0;
            RetrievalArrivalRateColumnArray= zeros(yy,2);
            for rowIndex=1:yy
                    %This part is for 0.25, 0.5, and 0.75 retrieval and arrival rates START
%                     if configurations(rowIndex,1)/BayCapacity <0.5
%                         RetrievalRate=0.25;
%                         ArrivalRate =0.75;
%                     elseif configurations(rowIndex,1)/BayCapacity ==0.5
%                         RetrievalRate=0.5;
%                         ArrivalRate =0.5;
%                     elseif configurations(rowIndex,1)/BayCapacity >0.5
%                         RetrievalRate=0.75;
%                         ArrivalRate =0.25;
%                     end
%                     This part is for 0.25, 0.5, and 0.75 retrieval and arrival rates END
%    This part is VARIABLE Retrieval and Arrival rate based on fullness rateSTART
                        RetrievalRate=configurations(rowIndex,1)/BayCapacity;
                        ArrivalRate = 1-RetrievalRate;
                        RetrievalArrivalRateColumnArray(rowIndex,1)=RetrievalRate;
                        RetrievalArrivalRateColumnArray(rowIndex,2)=ArrivalRate;
 %   This part is VARIABLE Retrieval and Arrival rate based on fullness rateSTART
            % This part BELOW is our BASE case scenario which has 0.5 rates
%             RetrievalArrivalRateColumnArray(rowIndex,1)=0.5;
%             RetrievalArrivalRateColumnArray(rowIndex,2)=0.5;
            % This part ABOVE is our BASE case scenario which has 0.5 rates
            end
 %END RetrievalRate and ArrivalRate calculation
 
        %below makes the transition matrix and calculates the steady state probabilities
        %transitionProbabilityCalculation(configurations, rows, tiers, ArrivalRate);
        TransitionMatrix = transitionProbabilityCalculationV4(configurations, rows, tiers, RetrievalArrivalRateColumnArray);  % calls the FUNCTION "transitionProbabilityCalculation "which constructs the "transitionMatrix"  
        [yyy,xxx] = size(TransitionMatrix);
        TransitionMatrix(1,2)=1;    % if the bay is empty then the next possible configuration can be with ONLY arrival which has only 1 container
        TransitionMatrix(1,1)=0;
        TransitionMatrix(yyy,xxx-1)=1; % if the bay is full then the next possible configuration can be with ONLY retrieval which has only minus 1 container from previous bay confi.
        TransitionMatrix(yyy,xxx)= 0;
% %         %format longindex=1;
        NormalizedRetrievalProbs = NormalizedRetrievalProbsV4( TransitionMatrix, RetrievalArrivalRateColumnArray);       % calls the FUNCTION "NormalizedRetrievalProbsV4" which constructs the "NormalizedRetrievalProbs" vector  


            format long
            [ExpectedRehandlesOfRowTierDesign, SQUAREExpectedRehandlesOfRowTierDesign, STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi,sumOfExpectedRehandlingforEachContainerinAConfiguration]= RehandledCalculationV4(configurations, NormalizedRetrievalProbs, rows, tiers); %calculates the number of rehandles for each row by tier design
           
            %ExpectedRehandlesOfRowTierDesign;    
            %sumOfExpectedRehandlingforEachContainerinAConfiguration;
            
                    %%NEWstandard deviation calculation
                    expectedXsquare = SQUAREExpectedRehandlesOfRowTierDesign;
                    standarddeviation = (expectedXsquare -  ExpectedRehandlesOfRowTierDesign.^2).^0.5;     
                    %%NEWstandard deviation calculation
                             
                    %Quartiles calculation
                    %Q1 = norminv(0.25, ExpectedRehandlesOfRowTierDesign,standarddeviation);   %%x = norminv(p,mu,sigma) returns the inverse of the normal cdf with mean mu and standard deviation sigma, evaluated at the probability values in p.
                    %Q3 = norminv(0.75, ExpectedRehandlesOfRowTierDesign,standarddeviation)
                    
                    %sirali = sort(STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi)
                    Quartiles = quantile(STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi,[0.25,0.5,0.75]) ;
                    
                                     %below to make all possible relocation numbers CELL to make the box plot
                                    %CellExpRelocationStoreforEachBayDesign{index}=STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi;
                                    index=index+1;
            
%xlswrite('totalRehandles.xlsx', NumberOfRehandles, 'rowtier')
 
totalNumbersOfRehandlesTable(rows+1,1)=rows;
totalNumbersOfRehandlesTable(1,tiers+1)=tiers;
totalNumbersOfRehandlesTable(rows+1,tiers+1)=ExpectedRehandlesOfRowTierDesign;
ExpectedRehandlesOfRowTierDesign
toc

% below we record the run time for each tierRow design
RunTimeTable(rows+1,1)=rows;
RunTimeTable(1,tiers+1)=tiers;
RunTimeTable(rows+1,tiers+1)=toc;

% below we record the standarddeviation for each tierRow design
StdDeviationTable(rows+1,1)=rows;
StdDeviationTable(1,tiers+1)=tiers;
StdDeviationTable(rows+1,tiers+1)=standarddeviation;

% below we record the QUARTILES for each tierRow design
matrixrow = (3*rows)+1 - 2  ;  % [(3*rows)+1] gives bottom indice of every particular row design and we subtract 2 to find the starting indice
QuartilesTable(matrixrow:matrixrow+2,1)=rows;
QuartilesTable(1,tiers+1)=tiers;
QuartilesTable(matrixrow:matrixrow+2,tiers+1)= Quartiles';

% FirstQuartilesTable(rows+1,1)=rows;
% FirstQuartilesTable(1,tiers+1)=tiers;
% FirstQuartilesTable(rows+1,tiers+1)=Q1;
% 
% ThirdQuartilesTable(rows+1,1)=rows;
% ThirdQuartilesTable(1,tiers+1)=tiers;
% ThirdQuartilesTable(rows+1,tiers+1)=Q3;
%VariousArrivalRateSummary(1,indexx)=ArrivalRate;   % new added for various arrival rates
%VariousArrivalRateSummary(2,indexx)=ExpectedRehandlesOfRowTierDesign;   % new added for various arrival rates
    end
end

%end    % new added for various arrival rates
%below we write all statistics to excel file
writematrix(totalNumbersOfRehandlesTable,'SUMMARYCrane.xlsx','Sheet','mean','Range','A1')
writematrix(StdDeviationTable,'SUMMARYCrane.xlsx','Sheet','sigma','Range','A1')
writematrix(QuartilesTable,'SUMMARYCrane.xlsx','Sheet','quartiles','Range','A1')
writematrix(RunTimeTable,'SUMMARYCrane.xlsx','Sheet','runtimes','Range','A1')


%writematrix(VariousArrivalRateSummary,'VariousArrivalRateSummary.xlsx','Sheet','mean','Range','B2') % new added for various arrival rates

                            %////////////////////// below I added make the box plot
%                                                 x = [CellExpRelocationStoreforEachBayDesign{1}'; CellExpRelocationStoreforEachBayDesign{2}'; CellExpRelocationStoreforEachBayDesign{3}';CellExpRelocationStoreforEachBayDesign{4}'
%                                                      CellExpRelocationStoreforEachBayDesign{5}'; CellExpRelocationStoreforEachBayDesign{6}'; CellExpRelocationStoreforEachBayDesign{7}';CellExpRelocationStoreforEachBayDesign{8}'];
%                                                 g45 = repmat({'4Rows 5Tiers'},length(CellExpRelocationStoreforEachBayDesign{1}),1);
%                                                 g46 = repmat({'4Rows 6Tiers'},length(CellExpRelocationStoreforEachBayDesign{2}),1);
%                                                 g47 = repmat({'4Rows 7Tiers'},length(CellExpRelocationStoreforEachBayDesign{3}),1);
%                                                 g48 = repmat({'4Rows 8Tiers'},length(CellExpRelocationStoreforEachBayDesign{4}),1);
%                                                 
%                                                 g55 = repmat({'5Rows 5Tiers'},length(CellExpRelocationStoreforEachBayDesign{5}),1);
%                                                 g56 = repmat({'5Rows 6Tiers'},length(CellExpRelocationStoreforEachBayDesign{6}),1);
%                                                 g57 = repmat({'5Rows 7Tiers'},length(CellExpRelocationStoreforEachBayDesign{7}),1);
%                                                 g58 = repmat({'5Rows 8Tiers'},length(CellExpRelocationStoreforEachBayDesign{8}),1);
%                                                  g = [g45; g46; g47; g48;   g55; g56; g57; g58];
%                                                 boxplot(x,g)
%                                                 xlabel('Bay Design')
%                                                 ylabel('Number of Relocations')
                            %////////////////////// above I added make the box plot 




%clear
%clc
% %%%&&&&&&&&&& temporary trial paramaters are given below
% steadyStateProbabilities= [0.25 0.25 0.25 0.25];
% configurations =[ 1 1; 2 2]
% rows= 1;
% tiers=2;
% %%%&&&&&&&&&&
function [ExpectedRehandlesOfRowTierDesign, SQUAREExpectedRehandlesOfRowTierDesign, STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi,sumOfExpectedRehandlingforEachContainerinAConfiguration] = RehandledCalculationV4(configurations, NormalizedRetrievalProbs, rows, tiers)
[aa,bb] = size(configurations); % 210 configurations and 7 columns(6 rows + total number of containers) for 6 rows and 4 tiers bay design
rehandleNumMatrix=zeros (aa,rows*tiers);  %210 by 6*4=24 matrix
for iiii=1:aa  
CandConfi=configurations(iiii,2:bb);   % gets the candidate configuration seperating from whole configuration matrix without summation column of '1'                 
       % initiate "order" indice to place a following possible configuration in a
       rehandleNumArray=zeros(1,rows*tiers); % creates zeros matrix for each container retrieval in a bay for that particular configuration(6*4=24 vector of zeros)
       order=0;
       
       if rows==1
            for candContTier=1:CandConfi(1)
            %candContTier=candContTier;
            rehandleNum=CandConfi(1)-candContTier;
            order=order+1;  %indice in array to store the number of above containers for each container in a configuration 
            rehandleNumArray(order)= 2*rehandleNum;
            %%%*********     
            end
       else
            for candContRow=1:bb-1   % bb = 7 so goes to until 6 rows
                %if CandConfi(candContRow)==0
                %break;
                    for candContTier=1:CandConfi(candContRow)
                        %candContTier=candContTier;
                        rehandleNum=CandConfi(candContRow)-candContTier;
                        order=order+1;  %indice in array to store the number of above containers for each container in a configuration 
                        rehandleNumArray(order)= rehandleNum;
                        %%%*********     
                    end
                %end
            end    %end of the loop for 1 row of the 'CandConfi' array to try each of containers in the bay retrieval
       end
    
rehandleNumMatrix(iiii,:)=[rehandleNumArray] ; 
% end of constructing all possible number of rehandling for each container retrieval in given configuration
end
%%%&&&&&&&&&&
rehandleNumMatrix;

%%%%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^START OF LOOP This loop will check if there is any retrieval needs EXTRA placement to prevent non-allowed stacking higher than the Tier number
%[aa,bb] = size(configurations)
for iiii= 1:aa 
 CandConfi=configurations(iiii,2:bb);   % gets the candidate configuration seperating from whole configuration matrix without summation column of '1'                 
 rehandleNumArray= rehandleNumMatrix(iiii,:);
 order=0;   % initiate "order" indice to place a following possible configuration in a 
    for candContRow=1:bb-1
            for candContTier=1:CandConfi(candContRow)
                possibleConfi=CandConfi;
                until=candContTier+1;    % we use "until" indice to run the below loop until the candidate container which is going to be retrieved
                    %below loop re-handling containers above the target container to the minimum tier row
                    for i = CandConfi(candContRow):-1:until
                     tempPossibleConfi=possibleConfi; %assigns possible configuration array to tempPossibleConfi to make the tier number of current candidate container row a big number not to choose the same row for placement
                     tempPossibleConfi(candContRow)=99;         %assigns a big number to the row of the candidate container to prevent confusion-because in next row code it can find the same row to place the removed container
                    [~,newrow]=min(tempPossibleConfi);    % finds the lowest tier number in a bay and finds the indice of the row which has the lowest tier. 'lowesttier' can be used to track 'symbolicBay' if I use it.
                    possibleConfi(candContRow)= possibleConfi(candContRow)-1; % after the removal of the candidate container, we decrease the tier number by 1
                    possibleConfi(newrow) = possibleConfi(newrow)+1; % after removing the container placed to the new row with a minimum tier, we increase the tier number by 1
                    end
                    %in above loop re-handling containers above the target container to the minimum tier row
            
                 possibleConfi(candContRow)= possibleConfi(candContRow)-1;   % decrease the target container row by 1 after the retrieval of target container 
                 possibleConfi= -sort(-possibleConfi);  % sort the possibleConfi array in a descending order
                 
                 %%%*********Loop for checking if there is any tier has more than maximum tier number, if so then take the extra containers to the lowest tiers(which probably the target container's row)
                     [highesttier,highestTierRow]= max(possibleConfi);
                     order=order+1 ; % to get the indice of extra rehandling in "rehandleNumArray" for each "CandConfi"
                     while highesttier > tiers
                            for j=1:(highesttier-tiers)
                            [~,newrowRevise]=min(possibleConfi);    % finds the lowest tier number in a bay and finds the indice of the row which has the lowest tier. 'lowesttier' can be used to track 'symbolicBay' if I use it. 
                            possibleConfi(highestTierRow) = possibleConfi(highestTierRow)-1;  % after the removal of the candidate container, we decrease the tier number by 1
                            possibleConfi(newrowRevise) = possibleConfi(newrowRevise)+1; % after the removed the container placed to the new row with a minimum tier, we increase the tier number by 1
                        
                            rehandleNumArray(order)=rehandleNumArray(order)+1;
                            %rehandleNumMatrix(iiii,order)=rehandleNumMatrix(iiii,order);
                            rehandleNumMatrix(iiii,order)=rehandleNumMatrix(iiii,order)+1;
                            end
                            [highesttier,highestTierRow]=max(possibleConfi);
                     end
                %possibleConfi;
                %%%*********
            end
    end    %end of the loop for 1 row of the 'CandConfi' array to try each of containers in the bay retrieval      
% end of constructing all possible configurations when there is a retrieval
end
    rehandleNumMatrix;   % stores the number of required containers to be removed to retrieve each container in a bay. every row of matrix stores number of required containers rehandling for each configuration
    %[m,n] = size(rehandleNumMatrix)
    %xlswrite('rehandleNumMatrix.xls', rehandleNumMatrix, 1, 'A1')
    %%%%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^END OF LOOP This loop will check if there is any retrieval needs EXTRA placement to prevent non-allowed stacking higher than the Tier number


ExpectedNumberOfrehandles = zeros(aa,1);  % creates empty zeros array to store ExpectedNumberOfrehandles of a bay considering the steadystate probs for each configuration when the bay has x rows and y tiers
sumOfExpectedRehandlingforEachContainerinAConfiguration = zeros(aa,1);  % creates empty zeros array to store column M in excel(#rehandling for each confi)
SQUAREsumOfExpectedRehandlingforEachContainerinAConfiguration = zeros(aa,1);
SQUAREExpectedNumberOfrehandles = zeros(aa,1);
STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi =[];
%totalContainers(:,1) = configurations(:,1); 
%sumOfExpectedRehandlingforEachConfigurationArray=zeros(aa,1);   % bunu artik kullanmiyorum cunku bunu sadece excel de steady state probabilityler ile carpmak icin kullanmisim.


for i= 1:aa    %total configurations number = 210 if there are 6 bays and 4 tiers. 210 configurations include empty bay confi too.
        if configurations(i,1)==0    % if the bay is empty
        ExpectedNumberOfrehandles(i,1)=0;  % the number of expected rehandles is 0. 
        STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi=[0];
        else   
        %rehandleNumMatrix (i,:); % only the row for that particular configuration(each row stores the number of required number of rehandled containers to reach each container in that configuration)
            %configurations(i,1);   % gets the total number of containers stacked in that particular configuration
            sumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) = sum (rehandleNumMatrix (i,:)/ configurations(i,1) );   %Column M values in excel "in paranthesis part" is an array.It finds the expected number of rehandling for each container retrieval in a configuration. In paranthesis means just multiplying((1/total number of container) equals to the probability of each container retrieval) by the each container pick up probability. 
            SQUAREsumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) = sum (rehandleNumMatrix (i,:).^2/ configurations(i,1) );
            %numofrownumberfromrehandleNumMatrix = configurations(i,1);
            CANDItoStoreNumofRelocations = rehandleNumMatrix (i,1:configurations(i,1));
            STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi = [STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi CANDItoStoreNumofRelocations];   % stores all possible relocations number for ever possible container in every possible configurations
        %in above row, we sum the expected number of Rehandling for each container retrieval to find the expected number of rehandling for any possible configuration  % "above summation" is the expected number of relocation for each configuration
        %sumOfExpectedRehandlingforEachConfigurationArray (i,1) = sumOfExpectedRehandlingforEachContainerinAConfiguration;  % bu satiri sadece array olusturup excel de hesaplatmamk icin eklemisim
        %steadyStateProbabilities (1,i) % gets the steady state prob of each configuration
        
        ExpectedNumberOfrehandles(i,1) = sumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) * NormalizedRetrievalProbs (1,i);  % this row stores the expected number of rehandling for each configuration of any RowTier design
        SQUAREExpectedNumberOfrehandles(i,1) = SQUAREsumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) * NormalizedRetrievalProbs (1,i);
        end
end
ExpectedNumberOfrehandles;  % this vector array stores the expected number of rehandling for each configuration for particular RowTier design

format long
ExpectedRehandlesOfRowTierDesign = sum(ExpectedNumberOfrehandles);  % ExpectedRehandlesOfRowTierConfiguration refers the bay structure of row and tier numbers. this row sums all expected number of rehandling for each possible configuration to find the numbers for RowTier design
SQUAREExpectedRehandlesOfRowTierDesign = sum(SQUAREExpectedNumberOfrehandles);
end


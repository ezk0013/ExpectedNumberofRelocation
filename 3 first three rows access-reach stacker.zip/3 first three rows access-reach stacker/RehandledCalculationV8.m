%    clc, clear
%    configurations =       [0     0     0     0     0     0     0;
%      1     1     0     0     0     0     0;
%      2     2     0     0     0     0     0;
%      3     3     0     0     0     0     0;
%      4     4     0     0     0     0     0;
%      5     4     1     0     0     0     0;
%      6     4     2     0     0     0     0;
%      7     4     3     0     0     0     0;
%      8     4     4     0     0     0     0;
%      9     4     4     1     0     0     0;
%     10     4     4     2     0     0     0;
%     11     4     4     3     0     0     0;
%     12     4     4     4     0     0     0;
%     13     4     4     4     1     0     0;
%     14     4     4     4     2     0     0;
%     15     4     4     4     3     0     0;
%     16     4     4     4     4     0     0;
%     17     4     4     4     4     1     0;
%     18     4     4     4     4     2     0;
%     19     4     4     4     4     3     0;
%     20     4     4     4     4     4     0;
%     21     4     4     4     4     4     1;
%     22     4     4     4     4     4     2;
%     23     4     4     4     4     4     3;
%     24     4     4     4     4     4     4];
%     steadyStateProbabilities= [0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04];
%     rows=6;
%     tiers= 4;

% %%%&&&&&&&&&&
function [ExpectedRehandlesOfRowTierDesign, SQUAREExpectedRehandlesOfRowTierDesign, STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi] = RehandledCalculationV8(configurations, NormalizedRetrievalProbs, rows, tiers, maxHeightCap)

rehandleNumMatrix = RehandlingMatrixEachContV8(configurations, rows, tiers, maxHeightCap);
%%%&&&&&&&&&&

%rehandleNumMatrix = rehandleNumMatrix
%xlswrite('rehandledmatrix.xlsx', rehandleNumMatrix, 'rowtier')

[aa,~] = size(configurations);
ExpectedNumberOfrehandles = zeros(aa,1);  % creates empty zeros array to store ExpectedNumberOfrehandles of a bay considering the steadystate probs for each configuration when the bay has x rows and y tiers
sumOfExpectedRehandlingforEachContainerinAConfiguration = zeros(aa,1);  % creates empty zeros array to store column M in excel(#rehandling for each confi)
SQUAREsumOfExpectedRehandlingforEachContainerinAConfiguration = zeros(aa,1);
SQUAREExpectedNumberOfrehandles = zeros(aa,1);
STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi =[];
%totalContainers(:,1) = configurations(:,1); 
%sumOfExpectedRehandlingforEachConfigurationArray=zeros(aa,1);   % bunu artik kullanmiyorum cunku bunu sadece excel de steady state probabilityler ile carpmak icin kullanmisim.


for i= 1:aa    %total configurations number = 210 if there are 6 bays and 4 tiers
        if configurations(i,1)==0    % if the bay is empty
        ExpectedNumberOfrehandles(i,1)=0;  % the number of expected rehandles is 0. 
        STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi=[0];
        else   
        %rehandleNumMatrix (i,:); % only the row for that particular configuration(each row stores the number of required number of rehandled containers to reach each container in that configuration)
            %configurations(i,1);   % gets the total number of containers stacked in that particular configuration
            sumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) = sum (rehandleNumMatrix (i,:)/ configurations(i,1) );   %Column M values in excel "in paranthesis part" is an array.It finds the expected number of rehandling for each container retrieval in a configuration. In paranthesis means just multiplying((1/total number of container) equals to the probability of each container retrieval) by the each container pick up probability. 
            SQUAREsumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) = sum (rehandleNumMatrix (i,:).^2/ configurations(i,1) );
            %numofrownumberfromrehandleNumMatrix = configurations(i,1);
            CANDItoStoreNumofRelocations = rehandleNumMatrix (i,1:configurations(i,1));
            STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi = [STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi CANDItoStoreNumofRelocations];   % stores all possible relocations number for ever possible container in every possible configurations
        %in above row, we sum the expected number of Rehandling for each container retrieval to find the expected number of rehandling for any possible configuration  % "above summation" is the expected number of relocation for each configuration
        %sumOfExpectedRehandlingforEachConfigurationArray (i,1) = sumOfExpectedRehandlingforEachContainerinAConfiguration;  % bu satiri sadece array olusturup excel de hesaplatmamk icin eklemisim
        %steadyStateProbabilities (1,i) % gets the steady state prob of each configuration
        
        ExpectedNumberOfrehandles(i,1) = sumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) * NormalizedRetrievalProbs (1,i);  % this row stores the expected number of rehandling for each configuration of any RowTier design
        SQUAREExpectedNumberOfrehandles(i,1) = SQUAREsumOfExpectedRehandlingforEachContainerinAConfiguration(i,1) * NormalizedRetrievalProbs (1,i);
        end
end
%ExpectedNumberOfrehandles ; % this vector array stores the expected number of rehandling for each configuration for particular RowTier design
%sumOfExpectedRehandlingforEachContainerinAConfiguration(i,1)
format long
ExpectedRehandlesOfRowTierDesign = sum(ExpectedNumberOfrehandles);  % ExpectedRehandlesOfRowTierConfiguration refers the bay structure of row and tier numbers. this row sums all expected number of rehandling for each possible configuration to find the numbers for RowTier design
SQUAREExpectedRehandlesOfRowTierDesign = sum(SQUAREExpectedNumberOfrehandles);
end


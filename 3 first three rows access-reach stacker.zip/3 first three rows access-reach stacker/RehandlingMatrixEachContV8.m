%    clc, clear
%    configurations =       [0     0     0     0     0     0     0;
%      1     1     0     0     0     0     0;
%      2     2     0     0     0     0     0;
%      3     3     0     0     0     0     0;
%      4     4     0     0     0     0     0;
%      5     4     1     0     0     0     0;
%      6     4     2     0     0     0     0;
%      7     4     3     0     0     0     0;
%      8     4     4     0     0     0     0;
%      9     4     4     1     0     0     0;
%     10     4     4     2     0     0     0;
%     11     4     4     3     0     0     0;
%     12     4     4     4     0     0     0;
%     13     4     4     4     1     0     0;
%     14     4     4     4     2     0     0;
%     15     4     4     4     3     0     0;
%     16     4     4     4     4     0     0;
%     17     4     4     4     4     1     0;
%     18     4     4     4     4     2     0;
%     19     4     4     4     4     3     0;
%     20     4     4     4     4     4     0;
%     21     4     4     4     4     4     1;
%     22     4     4     4     4     4     2;
%     23     4     4     4     4     4     3;
%     24     4     4     4     4     4     4];
%     steadyStateProbabilities= [0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04];
%     rows=6;
%     tiers= 4;

% %%%&&&&&&&&&&
function rehandleNumMatrix = RehandlingMatrixEachContV8(configurations, rows, tiers, maxHeightCap)
[aa,bb] = size(configurations);     %aa=25, bb =7

%maxHeightCap = maxHeightCap; %we assume that reach stacker can reach up to 8 height in first row 
    
    rehandleNumMatrix = zeros (aa,rows*tiers);
            for iiii=1:aa  
            CandConfi=configurations(iiii,2:bb);   % gets the candidate configuration seperating from whole configuration matrix without summation column of '1'  
                   CandConfi = CandConfi(CandConfi~=0);     % removing "0" values from an CandConfi array to count rehandled containers to reach the target container. now we do not have any empty rows.
                   rehandleNumArray=zeros(1,rows*tiers); % creates zeros array for each container retrieval in a bay for that particular configuration
                   order=0; % initiate "order" indice
                   newbb=length(CandConfi);   %newbb is the length of the CandCondi without any empty rows
                for candContRow=1:newbb
                     for candContTier=1:CandConfi(candContRow) % for loop for each container pick up from bottom container to top one for each row
            %                     frontCandConfi=CandConfi(candContRow+1:rows)   % "frontCandConfi"  array is assigned as a new array to calculate the number of containers in front of the target container 
            %                     ondekilertoplami=sum(frontCandConfi)           % calculates how many containers are needed to rehandled to retrieve the target container
                        if tiers <= maxHeightCap - 2  % if the reach stacker's minimum height capacity is higher than the design tiers which refers "tiers" parameter, we counts the rehandling number as below       
                                 %^^^^^^^^^^^^^^^^ asagisi reach stacker kapasitesinden (yani al tier dan )alcak tier yukseklikleri icin gecerli
                                if candContRow <= newbb-3   % if the target container is located further than edge 3 rows then do below
                                tempArray = CandConfi(candContRow:candContRow+2)- [candContTier candContTier-1 candContTier-1];    % the second part makes a temp array for 3 accesible array to count rehandled containers to access the target container. if target cont. tier is 3 the temp array is [3 2 2]
                                tempArray(tempArray<0)=0;   % it replaces negative values with zero not to affect the total rehandling number whe we sum the array value below
                                rehandleNum = 2 *   (   sum(tempArray)  +     sum( CandConfi (candContRow+3:newbb)  )   );  % since reach stacker only needs to rehandle the containers above the target container tier.
                                %%%% above "sum(tempArray)" only counts above target container on the targetcontainer row and next 2 rows.
                                %%%  above second part  counts the rows
                                %%%  which will be completely emptied up to access the 3 accesible rows from the edge
                                %%%  "CandConfi(newbb)" counts the last row containers
                                else   % ELSE IF the target container is located close to the edge 3 rows then do below
                                    %****** asagida accessible 3 row icin target container a access saglmak icin rehandle olacak contaiener lari saymak icin gecici array olusturuyorum.  
                                    cikarilacakOndekiSize=newbb-candContRow;  % newbb = 6 ise e CandContRow=5 ise 6-5=1 tane onde bir row. Bu row dan (candContTier-1) i cikartacam target container a ulasabilmek icin
                                    frontTargetCont = zeros(1,cikarilacakOndekiSize) + candContTier-1;
                                    cikarilacakarray = [candContTier frontTargetCont];   % "frontTargetCont" is an array made of 1 tier lower than the candContTier to reach the target container
                                    %****** buraya kadar
                                    tempArray = CandConfi(candContRow:newbb)- cikarilacakarray ; % burda ondeki rowlari candContTier-1 i cikardigim icin rowlar hep ayni olmasada calisiyor.Asagidaki row ile degistirdim
                                    %tempArray = CandConfi(candContRow:newbb)- [candContTier candContTier-1 candContTier-1];
                                tempArray(tempArray<0)=0;   % it replaces negative values with zero not to affect the total rehandling number whe we sum the array value below
                                rehandleNum = 2 *   sum(tempArray);  % since reach stacker only needs to rehandle the containers above the target container tier, "sum(tempArray)" only counts above target container.    
                                end
                                order=order+1;  %indice in array to store the number of above containers for each container in a configuration 
                                rehandleNumArray(order)= rehandleNum;
                                %^^^^^^^^^^^^^^^^ yukarisi reach stacker dan alcak tier
                                
                       elseif tiers <= maxHeightCap - 1     % if the reach stacker's minimum height capacity is higher than the design tiers which refers "tiers" parameter, we counts the rehandling number as below
                                 %^^^^^^^^^^^^^^^^ asagisi reach stacker dan alcak tier yukseklikleri icin gecerli(tier  7 olursa )
                                if candContRow <= newbb-2   % if the target container is located further than edge 2 rows then do below because only up to second row can be reached up to 7 tiers
                                tempArray = CandConfi(candContRow:candContRow+1)- [candContTier candContTier-1]; % since there are only 2 accesible rows, we make 2 by 1 temp array to count blocking containers to access target container
                                tempArray(tempArray<0)=0;   % it replaces negative values with zero not to affect the total rehandling number whe we sum the array value below
                                rehandleNum = 2 *   (   sum(tempArray)  +     sum( CandConfi (candContRow+2:newbb)  )   );  % since reach stacker only needs to rehandle the containers above the target container tier.
                                %%%% above "sum(tempArray)" only counts above target container on the targetcontainerrow and next 2 rows.
                                %%%  "(newbb-candContRow-1-1) * tiers "  counts the rows which will be completely emptied up to highesttier between reached 2 rows and the last row. "-1" refers next 1 rows after target row. "-1" refers the last row
                                %%%  "CandConfi(newbb)" counts the last row containers
                                else   % ELSE IF the target container is located close to the edge 2 rows then do below
                                                                        %****** asagida accessible 3 row icin target container a access saglmak icin rehandle olacak contaiener lari saymak icin gecici array olusturuyorum.  
                                    cikarilacakOndekiSize=newbb-candContRow;  % newbb = 6 ise e CandContRow=5 ise 6-5=1 tane onde bir row. Bu row dan (candContTier-1) i cikartacam target container a ulasabilmek icin
                                    frontTargetCont = zeros(1,cikarilacakOndekiSize) + candContTier-1;
                                    cikarilacakarray = [candContTier frontTargetCont];   % "frontTargetCont" is an array made of 1 tier lower than the candContTier to reach the target container
                                    %****** buraya kadar
                                    tempArray = CandConfi(candContRow:newbb)- cikarilacakarray ; % burda ondeki rowlari candContTier-1 i cikardigim icin rowlar hep ayni olmasada calisiyor.
                                %tempArray = CandConfi(candContRow:newbb)- [candContTier candContTier-1];
                                tempArray(tempArray<0)=0;   % it replaces negative values with zero not to affect the total rehandling number whe we sum the array value below
                                rehandleNum = 2 * sum(tempArray);  % since reach stacker only needs to rehandle the containers above the target container tier, "sum(tempArray)" only counts above target container.    
                                end
                                order=order+1;  %indice in array to store the number of above containers for each container in a configuration 
                                rehandleNumArray(order)= rehandleNum;
                                %^^^^^^^^^^^^^^^^ yukarisi reach stacker dan alcak tier
                                
                        else   % tiers =8 dir  % oda degilse zaten sadece 8 tiers vardir ve onun icinde sadece first row access olur ve top-lifter calculation ile ayni olur.      
                                %^^^^^^^^^^^^^^^^ asagisi reach stacker dan alcak tier yukseklikleri icin gecerli(tier  8 olursa )
                                rehandleNum = 2 * ( CandConfi(candContRow)-candContTier   + sum( CandConfi(candContRow+1:newbb) ) ) ;  % first two elements calculates the number of containers above the target container and the last element calculates the number of containers located in front of the target container row
                                order=order+1;  %indice in array to store the number of above containers for each container in a configuration 
                                rehandleNumArray(order)= rehandleNum;
                                %^^^^^^^^^^^^^^^^ yukarisi reach stacker dan alcak tier
                        end         
                                  
                     end
                end
            rehandleNumMatrix(iiii,:)=rehandleNumArray ;   
            end    %end of the loop for 1 row of the 'CandConfi' array to try each of containers in the bay retrieval
    
% end of constructing all possible number of rehandling for each container retrieval in given configuration
%end
%%%&&&&&&&&&&
rehandleNumMatrix;
%xlswrite('rehandledmatrix.xlsx', rehandleNumMatrix, 'rowtier')


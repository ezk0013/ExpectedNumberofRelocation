
function TransitionMatrix=transitionProbabilityCalculationV8(configurations, rows, tiers, ArrivalRate, maxHeightCap)


% clc, clear
% configurations =  [0     0     0     0     0;
%      1     1     0     0     0;
%      2     2     0     0     0;
%      2     1     1     0     0;
%      3     2     1     0     0;
%      3     1     1     1     0;
%      4     2     2     0     0;
%      4     2     1     1     0;
%      4     1     1     1     1;
%      5     2     2     1     0;
%      5     2     1     1     1;
%      6     2     2     2     0;
%      6     2     2     1     1;
%      7     2     2     2     1;
%      8     2     2     2     2];

% from row 58 to 153 in main script  % *********

% *********START transition Probabilities below it is going to make the transition probabilities

[yy,xx] = size(configurations);  % we get the size of configurations which is yy=210 and xx=7 to use yy indices to construct TransitionMatrix
TransitionMatrix =  zeros (yy,yy);  % we construct a TransitionMatrix of full '0's

%%%////////alttaki arayi function input u olarak ta alabilir
% rows=xx-1;
% tiers=max(max(configurations(:, 2:end)));
% %aa= configurations(:, 2:end)
% ArrivalRate=0.5;
%%%////////yukardaki parametreleri function input u olarakta alabilir

%^^^^^^^^^the loop below checks each configuration in "configurations"
%matrix to calculate "transitionProbs" vector for each configuration
for configurationsRow= 1:yy   % it checks all configurations in "configurations" matrix to make possible configurations after retrieval
CandConfi = configurations(configurationsRow,2:xx);   % gets the candidate configuration seperating from whole configuration matrix without summation column of '1'
%                     %%%%^^^^^^below we create possibleConfigurations matrix to store possible configurations after retrieval 
                    if sum(CandConfi)==0
                        possibleConfigurations = zeros (1,rows); %aslinda buna gerek yok cunku ana function da burayi duzeltiyorum tekrardan
                        % possibleConfigurations(1,1) = 1;  %this row is to change the transition probability when the bay is empty 
                    else
                         possibleConfigurations = zeros (sum(CandConfi), rows);  % construct a "possibleConfigurations" matrix of '0's which is made of total number of containers in a CandConfi having same number of rows with the CandConfi
                    end % end of if condition for empty bay
%                     %%%%^^^^^^above we create possibleConfigurations matrix to store possible configurations after retrieval
       order=0;   % initiate "order" indice to place a following possible configuration in a "possibleConfigurations" matrix
    
       %for candContRow=1:xx-1   % xx is 7 including the total number of containers column. That is why we are checking rows from 1 to 6.
        %tempnewConfi = zeros(1, rows-(candContRow-1)); 

                
                %%%%%(((((((((((((((((((((((((((((((((((((((((((((((((((((((burdan asagisi RehandlingMatrixeachCont function dan alindi      
                   %CandConfi=configurations(iiii,2:bb);   % gets the candidate configuration seperating from whole configuration matrix without summation column of '1' 
                   %tempCandConfi = CandConfi(candContRow:xx-1);
                   tempCandConfi = CandConfi(CandConfi~=0); %I use tempCandConfi only to counts rehandling. removing "0" values from an CandConfi array to count rehandled containers to reach the target container. now we do not have any empty rows.
                   %rehandleNumArray=zeros(1,rows*tiers); % creates zeros array for each container retrieval in a bay for that particular configuration
                   %order=0; % initiate "order" indice
                   newbb = length(tempCandConfi);   %newbb is the length of the CandCondi without any empty rows
                  for tempcandContRow=1:newbb
                      for candContTier=1:CandConfi(tempcandContRow) % run the loop until the writtenn number of tier located in that particular row.  % for loop for each container pick up from bottom container to top one for each row
                      %possibleConfi = CandConfi;  % initiate the possible configuration as the Candidate configuration
                      %possibleConfi(candContRow)= possibleConfi(candContRow)-1;   % decrease the target container row by 1 after the retrieval of "target" container   
            %                     fronttempCandConfi=tempCandConfi(tempcandContRow+1:rows)   % "fronttempCandConfi"  array is assigned as a new array to calculate the number of containers in front of the target container 
            %                     ondekilertoplami=sum(fronttempCandConfi)           % calculates how many containers are needed to rehandled to retrieve the target container
                        if tiers <= maxHeightCap - 2  % if the reach stacker's minimum height capacity is higher than the design tiers which refers "tiers" parameter, we counts the rehandling number as below       
                                %^^^^^^^^^^^^^^^^ asagisi reach stacker kapasitesinden (yani 6 tier dan )alcak tier yukseklikleri icin gecerli 
                                    OndekiRowsNumber = newbb-tempcandContRow;  % if newbb=6 and tempcandContRow=5 then 6-5=1 tane onde bir row. if newbb=4 and tempcandContRow=1 then 4-1=3 tane onde rows.
                                    if OndekiRowsNumber >=2
                                       AccessibleOndekiRowsNumber = 2;
                                       AccessibleBlockingContNumberArray = zeros(1, AccessibleOndekiRowsNumber) + (candContTier-1);%gecici"AccessibleBlockingContNumberArray(accesible rows icin)" olusturuyorum cikarmak icin.It is made of 1 tier lower than the candContTier to reach the target container.
                                       %Bu row dan (candContTier-1) i cikartiyorum cunku target container a ulasabilmek icin 
                                       FullAlinacakOndekiFullRowNumber = OndekiRowsNumber-2;
                                       BlockingFullRowArray = zeros(1,FullAlinacakOndekiFullRowNumber); %tum bosaltilacak row lar icin olustrulan gecici array."frontBlockingFullRowArray" boaldiktan sonraki bos rowlari temsil ediyor
                                    else
                                      AccessibleOndekiRowsNumber = OndekiRowsNumber;
                                      AccessibleBlockingContNumberArray = zeros(1, AccessibleOndekiRowsNumber) + (candContTier-1);%gecici"AccessibleBlockingContNumberArray(accesible rows icin)" olusturuyorum cikarmak icin.It is made of 1 tier lower than the candContTier to reach the target container.
                                      %Bu row dan (candContTier-1) i cikartiyorum cunku target container a ulasabilmek icin 
                                      BlockingFullRowArray = [] ;%tum bosaltilacak row lar icin olustrulan gecici array."frontBlockingFullRowArray" boaldiktan sonraki bos rowlari temsil ediyor
                                    end
                                    cikarilacakarray = [candContTier AccessibleBlockingContNumberArray BlockingFullRowArray];%"cikarilacakArray" rehandle olacak konteynirlar alindiktan sonraki durumu temsil ediyor.
                                    %****** buraya kadar
                                    tempArray = tempCandConfi(tempcandContRow:newbb)- cikarilacakarray; %"tempArray" ustten alinacak gecici array i temsil ediyor.Asagidaki row ile degistirdim.
                                    %tempArray = tempCandConfi(tempcandContRow:newbb)- [candContTier candContTier-1 candContTier-1];
                                    tempArray(tempArray<0)= 0;   % it replaces negative values with zero not to affect the total rehandling number when we sum the array value below
                                    rehandleNum = sum(tempArray);  % since reach stacker only needs to rehandle the containers above the target container tier, "sum(tempArray)" only counts above target container.
                                    ConfiUstAlinmis= tempCandConfi(tempcandContRow:newbb)- tempArray;
                                    %tempCandConfi(1:tempcandContRow-1)
                                    newConfi= [tempCandConfi(1:tempcandContRow-1) ConfiUstAlinmis] ;  % target konteynir a ulasilmasi icin gereken konteynirlar alindiktan sonraki hali
                                    newConfi(tempcandContRow) = newConfi(tempcandContRow)-1;  % decrease the target container row by 1 after the retrieval of "target" container 
                                
                                    emptypartofCandConfi= zeros(1, rows - length(newConfi));
                                    tempnewConfi = [newConfi emptypartofCandConfi];
                                %^^^^^^^^^^^^^^^^ yukarisi reach stacker dan alcak tier
                                
                       elseif tiers <= maxHeightCap - 1     % if the reach stacker's minimum height capacity is higher than the design tiers which refers "tiers" parameter, we counts the rehandling number as below
                                 %^^^^^^^^^^^^^^^^ asagisi reach stacker dan alcak tier yukseklikleri icin gecerli(tier  7 olursa )
                                    OndekiRowsNumber = newbb-tempcandContRow;  % if newbb=6 and tempcandContRow=5 then 6-5=1 tane onde bir row. if newbb=4 and tempcandContRow=1 then 4-1=3 tane onde rows.
                                    if OndekiRowsNumber >=1
                                       AccessibleOndekiRowsNumber = 1;
                                       AccessibleBlockingContNumberArray = zeros(1, AccessibleOndekiRowsNumber) + (candContTier-1);%gecici"AccessibleBlockingContNumberArray(accesible rows icin)" olusturuyorum cikarmak icin.It is made of 1 tier lower than the candContTier to reach the target container.
                                       %Bu row dan (candContTier-1) i cikartiyorum cunku target container a ulasabilmek icin 
                                       FullAlinacakOndekiFullRowNumber = OndekiRowsNumber-1;
                                       BlockingFullRowArray = zeros(1,FullAlinacakOndekiFullRowNumber); %tum bosaltilacak row lar icin olustrulan gecici array."frontBlockingFullRowArray" boaldiktan sonraki bos rowlari temsil ediyor
                                    else
                                      AccessibleOndekiRowsNumber = OndekiRowsNumber;
                                      AccessibleBlockingContNumberArray = zeros(1, AccessibleOndekiRowsNumber) + (candContTier-1);%gecici"AccessibleBlockingContNumberArray(accesible rows icin)" olusturuyorum cikarmak icin.It is made of 1 tier lower than the candContTier to reach the target container.
                                      %Bu row dan (candContTier-1) i cikartiyorum cunku target container a ulasabilmek icin 
                                      BlockingFullRowArray = [] ;%tum bosaltilacak row lar icin olustrulan gecici array."frontBlockingFullRowArray" boaldiktan sonraki bos rowlari temsil ediyor
                                    end
                                    cikarilacakarray = [candContTier AccessibleBlockingContNumberArray BlockingFullRowArray];%"cikarilacakArray" rehandle olacak konteynirlar alindiktan sonraki durumu temsil ediyor.
                                    %****** buraya kadar
                                    tempArray = tempCandConfi(tempcandContRow:newbb)- cikarilacakarray; %"tempArray" ustten alinacak gecici array i temsil ediyor.Asagidaki row ile degistirdim.
                                    %tempArray = tempCandConfi(tempcandContRow:newbb)- [candContTier candContTier-1 candContTier-1];
                                    tempArray(tempArray<0)= 0;   % it replaces negative values with zero not to affect the total rehandling number when we sum the array value below
                                    rehandleNum = sum(tempArray);  % since reach stacker only needs to rehandle the containers above the target container tier, "sum(tempArray)" only counts above target container.
                                    ConfiUstAlinmis= tempCandConfi(tempcandContRow:newbb)- tempArray;
                                    %tempCandConfi(1:tempcandContRow-1)
                                    newConfi= [tempCandConfi(1:tempcandContRow-1) ConfiUstAlinmis] ;  % target konteynir a ulasilmasi icin gereken konteynirlar alindiktan sonraki hali
                                    newConfi(tempcandContRow) = newConfi(tempcandContRow)-1;  % decrease the target container row by 1 after the retrieval of "target" container 
                                
                                    emptypartofCandConfi= zeros(1, rows - length(newConfi));
                                    tempnewConfi = [newConfi emptypartofCandConfi];
                                %^^^^^^^^^^^^^^^^ yukarisi reach stacker dan alcak tier
                                
                        else   % tiers =8 dir  % oda degilse zaten sadece 8 tiers vardir ve onun icinde sadece first row access olur ve top-lifter calculation ile ayni olur.      
                                %^^^^^^^^^^^^^^^^ asagisi reach stacker dan alcak tier yukseklikleri icin gecerli(tier  8 olursa )
                                    OndekiRowsNumber = newbb-tempcandContRow;  % if newbb=6 and tempcandContRow=5 then 6-5=1 tane onde bir row. if newbb=4 and tempcandContRow=1 then 4-1=3 tane onde rows.
                                    if OndekiRowsNumber >=0
                                       AccessibleOndekiRowsNumber = 0;
                                       AccessibleBlockingContNumberArray = zeros(1, AccessibleOndekiRowsNumber) + (candContTier-1);%gecici"AccessibleBlockingContNumberArray(accesible rows icin)" olusturuyorum cikarmak icin.It is made of 1 tier lower than the candContTier to reach the target container.
                                       %Bu row dan (candContTier-1) i cikartiyorum cunku target container a ulasabilmek icin 
                                       FullAlinacakOndekiFullRowNumber = OndekiRowsNumber-0;
                                       BlockingFullRowArray = zeros(1,FullAlinacakOndekiFullRowNumber); %tum bosaltilacak row lar icin olustrulan gecici array."frontBlockingFullRowArray" boaldiktan sonraki bos rowlari temsil ediyor
                                    else
%                                       AccessibleOndekiRowsNumber = OndekiRowsNumber;
%                                       AccessibleBlockingContNumberArray = zeros(1, AccessibleOndekiRowsNumber) + (candContTier-1);%gecici"AccessibleBlockingContNumberArray(accesible rows icin)" olusturuyorum cikarmak icin.It is made of 1 tier lower than the candContTier to reach the target container.
%                                       %Bu row dan (candContTier-1) i cikartiyorum cunku target container a ulasabilmek icin 
%                                       BlockingFullRowArray = [] ;%tum bosaltilacak row lar icin olustrulan gecici array."frontBlockingFullRowArray" boaldiktan sonraki bos rowlari temsil ediyor
                                    end
                                    cikarilacakarray = [candContTier AccessibleBlockingContNumberArray BlockingFullRowArray];%"cikarilacakArray" rehandle olacak konteynirlar alindiktan sonraki durumu temsil ediyor.
                                    %****** buraya kadar
                                    tempArray = tempCandConfi(tempcandContRow:newbb)- cikarilacakarray; %"tempArray" ustten alinacak gecici array i temsil ediyor.Asagidaki row ile degistirdim.
                                    %tempArray = tempCandConfi(tempcandContRow:newbb)- [candContTier candContTier-1 candContTier-1];
                                    tempArray(tempArray<0)= 0;   % it replaces negative values with zero not to affect the total rehandling number when we sum the array value below
                                    rehandleNum = sum(tempArray);  % since reach stacker only needs to rehandle the containers above the target container tier, "sum(tempArray)" only counts above target container.
                                    ConfiUstAlinmis= tempCandConfi(tempcandContRow:newbb)- tempArray;
                                    %tempCandConfi(1:tempcandContRow-1)
                                    newConfi= [tempCandConfi(1:tempcandContRow-1) ConfiUstAlinmis] ;  % target konteynir a ulasilmasi icin gereken konteynirlar alindiktan sonraki hali
                                    newConfi(tempcandContRow) = newConfi(tempcandContRow)-1;  % decrease the target container row by 1 after the retrieval of "target" container 
                                
                                    emptypartofCandConfi= zeros(1, rows - length(newConfi));
                                    tempnewConfi = [newConfi emptypartofCandConfi];
                                %^^^^^^^^^^^^^^^^ yukarisi reach stacker dan alcak tier
                        end                    
                        %&&&&&&&&&&&&&&&&&&&&&&&&
                                    possibleConfi= tempnewConfi;   % the rows before the target container row is added back to left side of the changed confi
                                    for filledrows=1:rows    % check every column 
                                        if rehandleNum > 0 &&  possibleConfi(filledrows)< tiers   % if there is any container to restack and there is any space in that row
                                          leftrehandle = rehandleNum - min (tiers- possibleConfi(filledrows), rehandleNum);  % update the rehandle num by decreasing the used number of containers  
                                          possibleConfi(filledrows) = possibleConfi(filledrows) + min (tiers- possibleConfi(filledrows), rehandleNum);   % increase that row by minimum of up to highest tier or number of rehandling container
                                          rehandleNum = leftrehandle;
                                        end     
                                    end       
                       possibleConfi;
                       order=order+1;  % to add a new "possibleConfi" array into the "possibleConfigurations" matrix, this row increases the 'order'  indice
                       possibleConfigurations(order,:)= possibleConfi;
                       %&&&&&&&&&&&&&&&&&&&&&&&&
                      end
                      
                  end   %end of the loop for 1 row of the 'CandConfi' array to try each of containers in the bay when there is a retrieval
                  
                        %%^^^^^^^^^
                            %%%---below we order all possible configurations and find cumulative summation to find the percentiles when there is a retrieval
                            [filteredPossibleConfigurations,~,ic] = unique(possibleConfigurations, 'rows', 'stable');
                            %filteredPossibleConfigurations;   % tekrarli configuration tek bir configuration olarak gosteriyor
                            Counts = accumarray(ic, 1);  % gives an array showing the cumulative summation of each different rows(configurations)
                            %Out = [Counts filteredPossibleConfigurations];  % sadece cumulative summation i possible configurations matrix in basina ekliyor            
                                    %below if condition makes 'possibleConfigurations' zeros which is same configuration itself [0 0 0 0 0 0] because there is no retrieval possible when there is no container in a bay. 
                                    if sum(CandConfi)==0
                                         percentiles=1;     % burasini 0 yaptim 1 idi. cunku empty bay tekrar empty olamaz assumption ini yaptik.
                                         transitionProbs = percentiles * (1-ArrivalRate); % gives the cumulative summation of each different rows(configurations)
                                    else
                                        percentiles = Counts / sum(CandConfi);  % gives the 'percentiles' vector using 'Counts' vector dividing total number of possible configurations(in other words total number of containers for that CandConfi vector)
                                        transitionProbs = percentiles * (1-ArrivalRate);% gives the cumulative summation of each different rows(configurations)
                                    end % END of if condition for empty bay to update the transitionProbs             
                            %%%---until here we calculate the percentiles of configurations when we retrieve a container from any spot in a bay
                            %transitionProbs;

                             A=configurations(1:end,2:end);   %takes only configurations part of 'configurations' matrix without summation column 
                             [yyy,~] = size(filteredPossibleConfigurations); % gets the matrix size index of "filteredPossibleConfigurations". "yyy" is the number of possible configurations
                            % for loop below finds the indices of each configuration in  'filteredPossibleConfigurations' matrix
                                order=0;
                                indexVector = zeros(1,yyy);
                                for j=1:yyy   % bu loop olusturulan butun configurations lari tek tek check etmek icin.
                                [~,iaR,~] = intersect(A,filteredPossibleConfigurations(j,1:end),'rows');  % iaR= indice of 'possibleConfiArrival' array in 'A' matrix.olusturulan possible configuration icin butun configurations lar icindeki indisini buluyor.A butun configurations matrix.
                                order=order+1;  % butun olusturulan possible configurations larin butun configurations matrix indeki indislerini store etmek icin sirali array olusturuyoz. 
                                indexVector(order)=iaR;   % ia= indices of each 'filteredpossibleConfigurations' in 'configurations' matrix  
                                end
                                %indexVector;

                            for i=1:yyy
                                TransitionMatrix(configurationsRow,indexVector(i))=transitionProbs(i);  % places the "calculatedtransitionProbs" into the 'TransitionMatrix'  
                            end
                        %%^^^^^^^^^                  
        %%%%%(((((((((((((((((((((((((((((((((((((((((((((((((((((((
       %end
%end     
                 %%%+++++++++ the start of constructing possible configuration when there is an INCOMING container instead of retrieval
                     %%******below checking if the bay is full 
                     if sum(CandConfi)==rows*tiers    % this "if" loop checks if the bay is FULL
                         possibleConfiArrival=CandConfi;   % if the bay is full, then the possible configuration after the arrival is same because there is no new container is allowed when the bay is full 
                     else
                     %%******above checking if the bay is full 
                        tempCandConfi=CandConfi; %assigns CandConfi to temparray to find the row with a minimum tier for incoming container
                         %%%^^^^
                         arrivingcontainer =1;
                         for candContRow=1:rows
                             if arrivingcontainer==1 && tempCandConfi(candContRow)<tiers
                             tempCandConfi(candContRow)= tempCandConfi(candContRow)+1; % this is because I assume that non-accesible rows are always full. so that whatever the number of rows are accessible,all of them are full 
                             arrivingcontainer = 0;
                             end
                         end
                             %%%%^^^^                                  
                     % the end of constructing a possible configuration when there is an incoming container instead of retrieval
                     possibleConfiArrival=tempCandConfi;
                     end
                     [~,iaA,~] = intersect(A,possibleConfiArrival,'rows'); % iaA= indice of 'possibleConfiArrival' array in 'A' matrix. A is without row summations of "configurations"
                     TransitionMatrix(configurationsRow,iaA)= ArrivalRate;
    %                end
                %%%+++++++++ the end of constructing possible configuration when there is an incoming container instead of retrieval  
end


%END of constructing all possible configurations for each candidate possible and calculate their transition probabilities

% *********END transition Probabilities below it is going to make the transition probabilities



% notes for empty and full bay transition probabilities
% row 42                        possibleConfigurations(1,1) = 1;  %this row is to change the transition probability when the bay is empty 
% row 90 percentiles=0;     % burasini 0 yaptim 1 idi. cunku empty bay tekrar empty olamaz assumption ini yaptik.
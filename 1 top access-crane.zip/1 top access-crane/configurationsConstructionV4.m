
function configurations = configurationsConstructionV4(rows, tiers)

%tic

    
configurations=zeros(tiers, rows);
%-----------------------from here it starts to construct the all configurations
%for loop below initiates the configurations only changing the first row of a bay from 1 to the tier number such as [1 0 0 0 0 0]  [2 0 0 0 0 0] [3 0 0 0 0 0] [4 0 0 0 0 0]
    for k=1:tiers
    configurations(k,1)= k; 
    end  
  
temp = configurations;    % assigning first branch to contruct other branches
y = tiers;
kesilecek = tiers; % gets the number of rows to cut from the whole configurations matrix to seperate the branch from whole configurations matrix
% START of construction loop from row 2 to last row. Construct the new configuration branches starting from row 2
order=tiers;
for index=2:rows
    for jj=1:y
        confi=temp(jj,:);
        for kk=1:temp(jj,index-1)
        confi(1,index)=kk;
        order=order+1;
        configurations(order,:)=  confi;
        end
    end
        if index == rows
            clear temp    % delete the summationRow column vector when the for loop ends to make more space
            clear confi
            break            
        end
%configurations;
temp = configurations(kesilecek+1:end,:);   % cuts the last constructed configuration brand so the new ones will be constructed based on this brand
[y,~] = size(temp);
kesilecek = kesilecek+y;
end
%configurations;  
% END of construction loop from row 2 to last row.Until here constructs the all configurations except the empty bay configuration [0 0 0 0 0 0]
configurations=[zeros(1,rows);configurations];  % creates empty bay configuration [0 0 0 0 0 0] and adds empty bay configuration to whole configurations matrix
%-----------------------until here constructs all configurations

summationRow=sum(configurations,2);    % summing the rows instead of columns saying "2"
configurations = [summationRow configurations];    % adding the summation column vector as te first column of the configurations matrix
clear summationRow   % delete the summationRow column vector to make more space
%configurations = sortrows(configurations,1);  % sorting the configurations matrix based on the total number of containers in a bay

% end
% end
%toc


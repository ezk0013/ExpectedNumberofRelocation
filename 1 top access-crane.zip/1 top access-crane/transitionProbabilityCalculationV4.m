
function TransitionMatrix=transitionProbabilityCalculationV4(configurations, rows, tiers, ArrivalRate)

% clc, clear
% configurations =  [0     0     0     0     0;
%      1     1     0     0     0;
%      2     2     0     0     0;
%      2     1     1     0     0;
%      3     2     1     0     0;
%      3     1     1     1     0;
%      4     2     2     0     0;
%      4     2     1     1     0;
%      4     1     1     1     1;
%      5     2     2     1     0;
%      5     2     1     1     1;
%      6     2     2     2     0;
%      6     2     2     1     1;
%      7     2     2     2     1;
%      8     2     2     2     2];

% from row 58 to 153 in main script  % *********

% *********START transition Probabilities below it is going to make the transition probabilities

[yy,xx] = size(configurations);  % we get the size of configurations which is yy=210 and xx=7 to use yy indices to construct TransitionMatrix
TransitionMatrix=  zeros (yy,yy);  % we construct a TransitionMatrix of full '0's

%^^^^^^^^^the loop below checks each configuration in "configurations"
%matrix to calculate "transitionProbs" vector for each configuration
for configurationsRow= 1:yy   % it checks all configurations in "configurations" matrix to make possible configurations after retrieval
CandConfi=configurations(configurationsRow,2:xx);   % gets the candidate configuration seperating from whole configuration matrix without summation column of '1'
%                   %%%%^^^^^^below we create possibleConfigurations matrix to store possible configurations after retrieval 
                    if sum(CandConfi)==0
                        possibleConfigurations = zeros (1,rows); %we do not need this since I modify this part in main function after all probs are calculated
                        %possibleConfigurations(1,1) = 1;  %this row is to change the transition probability when the bay is empty 
                    else
                         possibleConfigurations = zeros (sum(CandConfi),rows);  % construct a "possibleConfigurations" matrix of '0's 
                    end % end of if condition for empty bay
%                     %%%%^^^^^^above we create possibleConfigurations matrix to store possible configurations after retrieval
    order=0;   % initiate "order" indice to place a following possible configuration in a "possibleConfigurations" matrix
    for candContRow=1:xx-1   % xx is 7 including the total number of containers column. That is why we are checking rows from 1 to 6 for 6 rows configuration.
            for candContTier=1:CandConfi(candContRow)
                possibleConfi = CandConfi;
                until = candContTier+1;    % we use "until" indice to run the below loop until the candidate container which is going to be retrieved
                    %---below loop re-handling containers above the target containers to the minimum tier row
                    for i=CandConfi(candContRow):-1:until
                    tempPossibleConfi=possibleConfi;     %assigns possible configuration array to tempPossibleConfi to make the tier number of current candidate container row a big number not to choose the same row for placement
                    tempPossibleConfi(candContRow)= 99;   %assigns a big number to the row of the candidate container to prevent confusion-because in next row code it can find the same row to place the removed container
                    [~,newrow]=min(tempPossibleConfi);   %finds the lowest tier number in a bay and finds the indice of the row which has the lowest tier. 'lowesttier' can be used to track 'symbolicBay' if I use it.  
                    possibleConfi(candContRow)= possibleConfi(candContRow)-1; % after the removal of the candidate(not target) container, we decrease the tier number by 1
                    possibleConfi(newrow) = possibleConfi(newrow)+ 1; % after placing the removed container from above target container to the new row with a minimum tier, we increase the tier number by 1
                    end
                    %---above loop re-handling containers above the target containers to the minimum tier row  
                 %below retrieving the target container and make the configuration vector in order
                 possibleConfi(candContRow)= possibleConfi(candContRow)-1;   % decrease the target container row by 1 after the retrieval of "target" container 
                 possibleConfi= -sort(-possibleConfi);  % sort the possibleConfi array in a descending order
                      %%%*********Below Loop for checking if there is any tier has more than maximum tier number, if so then take the extra containers to the lowest tiers(which probably the target container's row
                     [highesttier,highestTierRow]=max(possibleConfi);
                     while highesttier > tiers
                            for j=1:(highesttier-tiers)
                            [~,newrowRevise]=min(possibleConfi);    % finds the lowest tier number in a bay and finds the indice of the row which has the lowest tier. 'lowesttier' can be used to track 'symbolicBay' if I use it. 
                            possibleConfi(highestTierRow)= possibleConfi(highestTierRow)-1;  % after the removal of the candidate container, we decrease the tier number by 1
                            possibleConfi(newrowRevise) = possibleConfi(newrowRevise)+1; % after removing the container placed to the new row with a minimum tier, we increase the tier number by 1
                            end
                            [highesttier,highestTierRow]=max(possibleConfi);
                     end
                     %%%********* Above loop for checking if there is any tier has more than maximum tier number,           
                 possibleConfi= -sort(-possibleConfi);  % sort the possibleConfi array in a descending order
                 order=order+1;  % to add a new "possibleConfi" array into the "possibleConfigurations" matrix, this row increases the 'order'  indice
                 possibleConfigurations(order,:)= possibleConfi;
            end
    end    %end of the loop for 1 row of the 'CandConfi' array to try each of containers in the bay when there is a retrieval
    %possibleConfigurations;  % this refers possible configurations when there is a retrieval
%END of constructing all possibleConfigurations for all configurations in "configurations" matrix  when there is a RETRIEVAL

            %%%---below we order all possible configurations and find cumulative summation to find the percentiles when there is a retrieval
            [filteredPossibleConfigurations,~,ic] = unique(possibleConfigurations, 'rows', 'stable');
            %filteredPossibleConfigurations;   % tekrarli configuration tek bir configuration olarak gosteriyor
            Counts = accumarray(ic, 1);  % gives an array showing the cumulative summation of each different rows(configurations)
            %Out = [Counts filteredPossibleConfigurations];  % sadece cumulative summation i possible configurations matrix in basina ekliyor            
                    %below if condition makes 'possibleConfigurations' zeros which is same configuration itself [0 0 0 0 0 0] because there is no retrieval possible when there is no container in a bay. 
                    if sum(CandConfi)==0
                         percentiles=1;     %We assume empty bay cannot stay as empty %we do not need this since I modify this part in main function after all probs are calculated
                         transitionProbs = percentiles * (1-ArrivalRate); % gives the cumulative summation of each different rows(configurations)
                    else
                        percentiles = Counts / sum(CandConfi);  % gives the 'percentiles' vector using 'Counts' vector dividing total number of possible configurations(in other words total number of containers for that CandConfi vector)
                        transitionProbs = percentiles * (1-ArrivalRate);% gives the cumulative summation of each different rows(configurations)
                    end % END of if condition for empty bay to update the transitionProbs             
            %%%---until here we calculate the percentiles of configurations when we retrieve a container from any spot in a bay
            %transitionProbs;
  
 %^^^^^^^^^^^^^^^BELOW places all retrieval configurations probabilities into the big TransitioMatrix
 A=configurations(1:end,2:end);   %takes only configurations part of 'configurations' matrix without summation column 
 [yyy,~] = size(filteredPossibleConfigurations); % gets the matrix size index of "filteredPossibleConfigurations". "yyy=210" is the number of possible configurations
        % for loop below finds the indices of each configuration in  'filteredPossibleConfigurations' matrix
        order=0;
        indexVector = zeros(1,yyy);
        for j=1:yyy   % it checks all possible configurations one by one.
        [~,iaR,~] = intersect(A,filteredPossibleConfigurations(j,1:end),'rows');  % iaR= indice of 'possibleConfiArrival' array in 'A' matrix.olusturulan possible configuration icin butun configurations lar icindeki indisini buluyor.A butun configurations matrix.
        order=order+1;  % butun olusturulan possible configurations larin butun configurations matrix indeki indislerini store etmek icin sirali array olusturuyoz. 
        indexVector(order)=iaR;   % ia= indices of each 'filteredpossibleConfigurations' in 'configurations' matrix  
        end
        %indexVector;
        
        for i=1:yyy
            TransitionMatrix(configurationsRow,indexVector(i))=transitionProbs(i);  % places the "calculatedtransitionProbs" into the 'TransitionMatrix'  for RETRIEVAL
        end
  %^^^^^^^^^^^^^^^ABOVE places all retrieval configurations probabilities into the big TransitioMatrix
                 
                %%%+++++++++ the start of constructing possible configuration when there is an ARRIVAL container instead of retrieval
                   %%******below checking if the bay is full 
                 if sum(CandConfi)==rows*tiers    % this "if" loop checks if the bay is FULL
                 possibleConfiArrival=CandConfi;   % if the bay is full, then the possible configuration after the arrival is same because there is no new container is allowed when the bay is full. But I change it in main function as when the bay is full, there is only retrieval.
                 %TransitionMatrix(configurationsRow,yy-1)= 1;
                 %possibleConfiArrival=[];
%                  elseif sum(CandConfi)==0
%                  TransitionMatrix(configurationsRow,2)= 1;   
                 else
                   %%******above checking if the bay is full 
                 tempCandConfi=CandConfi; %assigns CandConfi to temporary array to to find the row with a minimum tier for incoming container
                 [~,newrow]=min(tempCandConfi);   % finds the lowest tier number in a bay and finds which row has the lowest tier
                 tempCandConfi(newrow) = tempCandConfi(newrow)+1; % after placing the arriving container to the lowest tier, we increase the tier number by '1'                
                 tempCandConfi= -sort(-tempCandConfi);  % we sort the  tempCandConfi array to make the configuration standart
                 % the end of constructing a possible configuration when there is an arrival container instead of retrieval
                 possibleConfiArrival=tempCandConfi;
                 end
                 [~,iaA,~] = intersect(A,possibleConfiArrival,'rows'); % iaA= indice of 'possibleConfiArrival' array in 'A' matrix. A is without row summations of "configurations"
                 TransitionMatrix(configurationsRow,iaA)= ArrivalRate;
%                  end
                 %%%+++++++++ the end of constructing possible configuration when there is an ARRIVAL container instead of retrieval

                 
end

end

%END of constructing all possible configurations for each candidate possible and calculate their transition probabilities

% *********END transition Probabilities below it is going to make the transition probabilities



% notes for empty and full bay transition probabilities
% row 42                        possibleConfigurations(1,1) = 1;  %this row is to change the transition probability when the bay is empty 
% row 90 percentiles=0;     % burasini 0 yaptim 1 idi. cunku empty bay tekrar empty olamaz assumption ini yaptik.

function configurations = configurationsConstructionV8(rows, tiers)
      
configurations=zeros(tiers*rows, rows);
% BELOW, initializes the highest tier number for each row
yAxis= tiers+1;
for k=1:rows-1 
    configurations(yAxis:tiers*rows,k)=tiers;
    yAxis= yAxis+tiers;
end
% UNTIL HERE, initializes the highest tier number for each row
%configurations;

% BELOW we make different combination leaving the previous rows as highest tier number 
    order = 0;
    for rowIndice=1:rows 
        for tierIndice=1:tiers
            order =order+1;
            configurations(order, rowIndice)= tierIndice; 
        end
    end
% UNTIL HERE we make different combination leaving the previous rows as highest tier number 

configurations=[zeros(1,rows);configurations];  % creates empty bay configuration [0 0 0 0 0 0] and adds empty bay configuration to whole configurations matrix
%-----------------------until here constructs all configurations

summationRow=sum(configurations,2);    % summing the rows instead of columns saying "2"
configurations = [summationRow configurations];    % adding the summation column vector as te first column of the configurations matrix
clear summationRow   % delete the summationRow column vector to make more space
%configurations = sortrows(configurations,1)  % sorting the configurations matrix based on the total number of containers in a bay

configurations = sortrows(configurations,1);  % sorting the configurations matrix based on the total number of containers in a bay
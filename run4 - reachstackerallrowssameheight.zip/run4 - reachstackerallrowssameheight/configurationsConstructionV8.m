
%row 13 to 53
function configurations = configurationsConstructionV8(rows, tiers,  maxHeightCap)
%tic
% for rows= highestRow 
%     for tiers=highestTier       
configurations=zeros(tiers, rows);
%-----------------------from here it starts to construct the all configurations
%for loop below initiates the configurations only changing the first row of a bay from 1 to the tier number such as [1 0 0 0 0 0]  [2 0 0 0 0 0] [3 0 0 0 0 0] [4 0 0 0 0 0]
    for k=1:tiers
    configurations(k,1)= k; 
    end  
  
temp = configurations;    % assigning first branch to contruct other branches
[y,~] = size(temp);
kesilecek = tiers; % gets the number of rows to cut from the whole configurations matrix to seperate the branch from whole configurations matrix

% START of construction loop from row 2 to last row. Construct the new configuration branches starting from row 2
order = tiers;   % burda yeni eklenecek configurations icin order indisi initiate ediliyor

%******* asagida butun row lar sirasiyla seciliyor
for CandRow=2:rows
    %&&&&&& asagida butun parent configuration lar birer birer seciliyor
    for jj=1:y      % "y" parent configuration matrix teki toplam configurations sayisi. jj indisi butun configuration lardan yeni configurationlar uretecek 
        confi=temp(jj,:);  % parent matrix deki jj sirasindaki configuration seciliyor yeni spring configuration olusturmak icin.
        %^^^^^^^
        for kk=1:temp(jj,CandRow-1)    % yeni olusturulacak configuration icin candidate row u "1" den baslayarak "kk" olarak bir onceki row yuksekligine kadar birer birer ata
        confi(1,CandRow)=kk;  % ilk for loop taki secilen "CandRow" u yukarda atanan kk i ata 
        
        % ////////below make the further row as highest tier since reach stacker cannot reach that row without removing all blocking rows containers
        if tiers <= maxHeightCap - 2  % if the reach stacker's minimum height capacity is higher than the design tiers which refers "tiers" parameter, we counts the rehandling number as below       
        %^^^^^^^^^^^^^^^^ asagisi reach stacker kapasitesinden (yani al tier dan )alcak tier yukseklikleri icin gecerli
        accesibleRows= 3;
        elseif tiers <= maxHeightCap - 1     % if the reach stacker's minimum height capacity is higher than the design tiers which refers "tiers" parameter, we counts the rehandling number as below
        %^^^^^^^^^^^^^^^^ asagisi reach stacker dan alcak tier yukseklikleri icin gecerli(tier  7 olursa )
        accesibleRows= 2;                         
        else   % tiers =8 dir  % oda degilse zaten sadece 8 tiers vardir ve onun icinde sadece first row access olur ve top-lifter calculation ile ayni olur.      
        %^^^^^^^^^^^^^^^^ asagisi reach stacker dan alcak tier yukseklikleri icin gecerli(tier  8 olursa )   
        accesibleRows= 1; 
        end 
                    if CandRow > accesibleRows     % if the candidate row is greater than number of accesible rows (3 if highest tier of bay is lower than 6) 
                    confi(1,CandRow-accesibleRows)=tiers;    % new created spring configuration's 3 further rows tier should be the highest  
                    end
        % ////////until here make the further row as highest tier since reach stacker cannot reach that row without removing all blocking rows containers
        
        order=order+1;    % bir sonraki possible configuration icin order i bir artir
        configurations(order,:) =  confi;    % yukarda row u degistirilen configurations i yeni bir configuration olarak bir onceki parent configurations matrix e ekle
        end   
        %^^^^^^^ burda yeni muhtemelen tier degerlerinin loop u bitiyor
    end
    %&&&&&& yukarida butun parent configuration lar birer birer seciliyor
    
            if CandRow == rows
            clear temp    % delete the summationRow column vector when the for loop ends to make more space
            clear confi
            break            
            end
%configurations;
temp = configurations(kesilecek+1:end,:);   % cuts the last constructed configuration brand so the new ones will be constructed based on this brand
[y,~] = size(temp); % en son kesilen parent configurations in sayisini bir sonraki row da kesmek icin y yi buluyorum
kesilecek = kesilecek+y;   % burda butun configuration larin oldugu matristen onceki kullanilmis parent configurations lari tekrar kullanmamak icin silinecek haric tutulacak sayiyi belirliyorum
end
%******* yukarida butun row lar sirasiyla seciliyor

%configurations
% END of construction loop from row 2 to last row.Until here constructs the all configurations except the empty bay configuration [0 0 0 0 0 0]
configurations = unique(configurations,'rows');

configurations=[zeros(1,rows);configurations];  % creates empty bay configuration [0 0 0 0 0 0] and adds empty bay configuration to whole configurations matrix
% -----------------------until here constructs all configurations
summationRow=sum(configurations,2);    % summing the rows instead of columns saying "2"
configurations = [summationRow configurations];    % adding the summation column vector as te first column of the configurations matrix
clear summationRow   % delete the summationRow column vector to make more space
configurations = sortrows(configurations,1);  % sorting the configurations matrix based on the total number of containers in a bay




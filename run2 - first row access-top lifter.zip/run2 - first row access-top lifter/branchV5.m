clear
clc

ArrivalRate=0.5;
highestRow=12;
highestTier=8;
totalNumbersOfRehandlesTable=zeros(highestRow+1,highestTier+1);  % -4 and -2 because of the loops start from 4 and 2
tic
for rows = 5% 1:highestRow 
    for tiers=  4% 1:highestTier
        rows
        tiers
        configurations = configurationsConstructionV5(rows, tiers) ;           % calls the FUNCTION "configurationsConstruction" which constructs the "configurations" matrix

        %below makes the transition matrix and calculates the steady state probabilities
        %transitionProbabilityCalculation(configurations, rows, tiers, ArrivalRate);
        TransitionMatrix=transitionProbabilityCalculationV5(configurations, rows, tiers, ArrivalRate);  % calls the FUNCTION "transitionProbabilityCalculation "which constructs the "transitionMatrix"  
        [yyy,xxx] = size(TransitionMatrix);
        TransitionMatrix(1,2)=1;
         TransitionMatrix(1,1)=0;
         TransitionMatrix(yyy,xxx-1)=1;
         TransitionMatrix(yyy,xxx)=0;
% %         %format long
       % NormalizedRetrievalProbs = NormalizedRetrievalProbsV5(TransitionMatrix, ArrivalRate);       % calls the FUNCTION "NormalizedRetrievalProbsV4" which constructs the "NormalizedRetrievalProbs" vector  
       [NormalizedRetrievalProbs, steadyStateProbabilities] = NormalizedRetrievalProbsV5(TransitionMatrix, ArrivalRate);
% S4= [0.25 0.25 0.25 0.25];
% CandConfigurations =[5 5 4 4 4 1; 5 5 5 4 4 0 ; 4 4 4 4 4 3; 5 4 4 4 4 2]
            %             [y,x] = size(configurations); % y =210, x = 7 for 4 tiers and 6 rows  alttaki for loop bu y ye kadar olacak    $$$BURASI sSILINEBILIR CUNKU Y KULLANILMIYOR VE X DE YUKARDAN BELLI GELIYOR ZATEN
            %             NumberOfRehandles=zeros(tiers*rows,1);  % creates empty zeros array to store "number of rehandles" for each rows and tiers combination when the number of containers are from 1 to full bay(tiers*rows)
            %             for numContainers=  1:tiers*rows     %it will store from 1 to full bay(tiers*rows) containers
            %             %SteadystateProbsforpossibleIndices=[];     % gets the steady state probabilities of each configuration of any number of containers from "steadyStateProbabilities" array
            %             %CandConfigurations=[];   % will store the configurations from "configurations" matrix based on "SteadyIndice" array
            %             possibleIndices = find(configurations(:,1)==numContainers)';   % finds the possible configurations' indices from "configurations" matrix for different "numContainers"
            %             SteadystateProbsforpossibleIndices= steadyStateProbabilities(possibleIndices); % gets the steady state probabilities from "steadyStateProbabilities" matching with the indeces in "possibleIndices"
            %             CandConfigurations= configurations(possibleIndices,2:x);  %gets the configurations which have the given number of containers using "possibleIndices" array. 
            format long
            ExpectedRehandlesOfRowTierDesign= RehandledCalculationV5(configurations, NormalizedRetrievalProbs, rows, tiers) %calculates the number of rehandles for each row by tier design
           
            %             end
           %ExpectedRehandlesOfRowTierDesign       
            
%xlswrite('totalRehandles.xlsx', NumberOfRehandles, 'rowtier')
 
totalNumbersOfRehandlesTable(rows+1,1)=rows;
totalNumbersOfRehandlesTable(1,tiers+1)=tiers;
totalNumbersOfRehandlesTable(rows+1,tiers+1)=ExpectedRehandlesOfRowTierDesign;

toc

% below we record the run time for each tierRow design
RunTimeTable(rows+1,1)=rows;
RunTimeTable(1,tiers+1)=tiers;
RunTimeTable(rows+1,tiers+1)=toc;
    end
end

xlswrite('summary.xls', totalNumbersOfRehandlesTable, 1, 'A1')
xlswrite('summary.xls', RunTimeTable, 2, 'A1')


% writematrix(totalNumbersOfRehandlesTable,'myExcelWorkbook.xls','Sheet',1,'Range','A1:F9','UseExcel',false); 
% writematrix(RunTimeTable,'myExcelWorkbook.xls','Sheet',2,'Range','A1:F9','UseExcel',false);










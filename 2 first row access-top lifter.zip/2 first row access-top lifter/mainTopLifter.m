
function mainTopLifter()
ArrivalRate=0.5;
highestRow=9;
highestTier=8;
totalNumbersOfRehandlesTable=zeros(highestRow+1,highestTier+1);  % -4 and -2 because of the loops start from 4 and 2
tic
index=1;
for rows =  1:highestRow 
    for tiers= 1:highestTier
        rows
        tiers
        configurations = configurationsConstructionV5(rows, tiers) ;           % calls the FUNCTION "configurationsConstruction" which constructs the "configurations" matrix

        %below makes the transition matrix and calculates the steady state probabilities
        %transitionProbabilityCalculation(configurations, rows, tiers, ArrivalRate);
        TransitionMatrix=transitionProbabilityCalculationV5(configurations, rows, tiers, ArrivalRate);  % calls the FUNCTION "transitionProbabilityCalculation "which constructs the "transitionMatrix"  
        [yyy,xxx] = size(TransitionMatrix);
        TransitionMatrix(1,2)=1;
        TransitionMatrix(1,1)=0;
        TransitionMatrix(yyy,xxx-1)=1;
        TransitionMatrix(yyy,xxx)=0;

       [NormalizedRetrievalProbs, steadyStateProbabilities] = NormalizedRetrievalProbsV5(TransitionMatrix, ArrivalRate);

            format long
            %ExpectedRehandlesOfRowTierDesign= RehandledCalculationV5(configurations, NormalizedRetrievalProbs, rows, tiers) %calculates the number of rehandles for each row by tier design
           [ExpectedRehandlesOfRowTierDesign, SQUAREExpectedRehandlesOfRowTierDesign, STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi]= RehandledCalculationV5(configurations, NormalizedRetrievalProbs, rows, tiers); %calculates the number of rehandles for each row by tier design
           

           %ExpectedRehandlesOfRowTierDesign 
           %sumOfExpectedRehandlingforEachContainerinAConfiguration;
           
                    %%NEWstandard deviation calculation
                    expectedXsquare = SQUAREExpectedRehandlesOfRowTierDesign;
                    standarddeviation = (expectedXsquare -  ExpectedRehandlesOfRowTierDesign.^2).^0.5;     
                    %%NEWstandard deviation calculation
                             
                    %Quartiles calculation
%                     Q1 = norminv(0.25, ExpectedRehandlesOfRowTierDesign,standarddeviation)   %%x = norminv(p,mu,sigma) returns the inverse of the normal cdf with mean mu and standard deviation sigma, evaluated at the probability values in p.
%                     Q3 = norminv(0.75, ExpectedRehandlesOfRowTierDesign,standarddeviation)

                    %SortedArray= sort(STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi)
                    Quartiles = quantile(STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi,[0.25,0.5,0.75]) ;
                    
                    %below to make all possible relocation numbers CELL to make the box plot
                    %CellExpRelocationStoreforEachBayDesign{index}=STOREExpectedRelocationforEveryPossibleContainerinEveryPosConfi;
                    index=index+1; 
                    
%xlswrite('totalRehandles.xlsx', NumberOfRehandles, 'rowtier')
totalNumbersOfRehandlesTable(rows+1,1)=rows;
totalNumbersOfRehandlesTable(1,tiers+1)=tiers;
totalNumbersOfRehandlesTable(rows+1,tiers+1)=ExpectedRehandlesOfRowTierDesign;

toc

% below we record the run time for each tierRow design
RunTimeTable(rows+1,1)=rows;
RunTimeTable(1,tiers+1)=tiers;
RunTimeTable(rows+1,tiers+1)=toc;


% below we record the standarddeviation for each tierRow design
StdDeviationTable(rows+1,1)=rows;
StdDeviationTable(1,tiers+1)=tiers;
StdDeviationTable(rows+1,tiers+1)=standarddeviation;

% below we record the QUARTILES for each tierRow design
matrixrow = (3*rows)+1 - 2  ;  % [(3*rows)+1] gives bottom indice of every particular row design and we subtract 2 to find the starting indice
QuartilesTable(matrixrow:matrixrow+2,1)=rows;
QuartilesTable(1,tiers+1)=tiers;
QuartilesTable(matrixrow:matrixrow+2,tiers+1)= Quartiles';

% FirstQuartilesTable(rows+1,1)=rows;
% FirstQuartilesTable(1,tiers+1)=tiers;
% FirstQuartilesTable(rows+1,tiers+1)=Q1;
% 
% ThirdQuartilesTable(rows+1,1)=rows;
% ThirdQuartilesTable(1,tiers+1)=tiers;
% ThirdQuartilesTable(rows+1,tiers+1)=Q3;
    end
end

% below we write all statistics to excel file
writematrix(totalNumbersOfRehandlesTable,'SUMMARYTopLifter.xlsx','Sheet','mean','Range','A1')
writematrix(StdDeviationTable,'SUMMARYTopLifter.xlsx','Sheet','sigma','Range','A1')
writematrix(QuartilesTable,'SUMMARYTopLifter.xlsx','Sheet','quartiles','Range','A1')
writematrix(RunTimeTable,'SUMMARYTopLifter.xlsx','Sheet','runtimes','Range','A1')


%                             %////////////////////// below I added make the box plot
%                                                 x = [CellExpRelocationStoreforEachBayDesign{1}'; CellExpRelocationStoreforEachBayDesign{2}'; CellExpRelocationStoreforEachBayDesign{3}';CellExpRelocationStoreforEachBayDesign{4}'
%                                                      CellExpRelocationStoreforEachBayDesign{5}'; CellExpRelocationStoreforEachBayDesign{6}'; CellExpRelocationStoreforEachBayDesign{7}';CellExpRelocationStoreforEachBayDesign{8}'];
%                                                 g45 = repmat({'4Rows 5Tiers'},length(CellExpRelocationStoreforEachBayDesign{1}),1);
%                                                 g46 = repmat({'4Rows 6Tiers'},length(CellExpRelocationStoreforEachBayDesign{2}),1);
%                                                 g47 = repmat({'4Rows 7Tiers'},length(CellExpRelocationStoreforEachBayDesign{3}),1);
%                                                 g48 = repmat({'4Rows 8Tiers'},length(CellExpRelocationStoreforEachBayDesign{4}),1);
%                                                 
%                                                 g55 = repmat({'5Rows 5Tiers'},length(CellExpRelocationStoreforEachBayDesign{5}),1);
%                                                 g56 = repmat({'5Rows 6Tiers'},length(CellExpRelocationStoreforEachBayDesign{6}),1);
%                                                 g57 = repmat({'5Rows 7Tiers'},length(CellExpRelocationStoreforEachBayDesign{7}),1);
%                                                 g58 = repmat({'5Rows 8Tiers'},length(CellExpRelocationStoreforEachBayDesign{8}),1);
%                                                  g = [g45; g46; g47; g48;   g55; g56; g57; g58];
% 
%                                                 figure
%                                                 subplot(3,1,1) 
%                                                 boxplot(x,g)
%                                                 title('Top Lifter')
%                                                 xlabel('Bay Design')
%                                                 ylabel('Number of Relocations')
% %                                                 hold on
%                                                  %y =sort(x)
%                             %////////////////////// above I added make the box plot 

end








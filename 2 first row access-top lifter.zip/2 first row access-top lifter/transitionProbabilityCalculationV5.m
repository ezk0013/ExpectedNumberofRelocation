
function TransitionMatrix = transitionProbabilityCalculationV5(configurations, rows, tiers, ArrivalRate)
% clc, clear
% rows=6;
% tiers= 4;
% ArrivalRate =0.6;
%    configurations =       [0     0     0     0     0     0     0;
%      1     1     0     0     0     0     0;
%      2     2     0     0     0     0     0;
%      3     3     0     0     0     0     0;
%      4     4     0     0     0     0     0;
%      5     4     1     0     0     0     0;
%      6     4     2     0     0     0     0;
%      7     4     3     0     0     0     0;
%      8     4     4     0     0     0     0;
%      9     4     4     1     0     0     0;
%     10     4     4     2     0     0     0;
%     11     4     4     3     0     0     0;
%     12     4     4     4     0     0     0;
%     13     4     4     4     1     0     0;
%     14     4     4     4     2     0     0;
%     15     4     4     4     3     0     0;
%     16     4     4     4     4     0     0;
%     17     4     4     4     4     1     0;
%     18     4     4     4     4     2     0;
%     19     4     4     4     4     3     0;
%     20     4     4     4     4     4     0;
%     21     4     4     4     4     4     1;
%     22     4     4     4     4     4     2;
%     23     4     4     4     4     4     3;
%     24     4     4     4     4     4     4]

% *********START transition Probabilities below it is going to make the transition probabilities

[yy,xx] = size(configurations);    % we get the size of configurations which is yy=25 and xx=7 to use yy indices to construct TransitionMatrix
TransitionMatrix =  zeros (yy,yy);  % we construct a TransitionMatrix of full '0's

%^^^^^^^^^the loop below checks each configuration in "configurations"
%matrix to calculate "transitionProbs" vector for each configuration
for configurationsRow = 1:yy   % it checks all configurations in "configurations" matrix to make possible configurations after retrieval
    CandConfi=configurations(configurationsRow,2:xx);   % gets the candidate configuration seperating from whole configuration matrix without summation column of '1'
    if sum(CandConfi)==0
    %possibleConfi = CandConfi;
    TransitionMatrix(configurationsRow,configurationsRow) =1- ArrivalRate;
    else
            %%%%******I deleted below since I do not need to follow the possible
            %%%%configurations since candidate configurations follow a
            %%%%structure that it can be only the configuration above in
            %%%%configurations matric
            %     possibleConfi = CandConfi;
            %     temppossibleConfi = possibleConfi ;        %Copy x into x1 if you don't want to lose x1
            %     temppossibleConfi(possibleConfi<=0) = NaN;  %Set anything <= 0 to NaN
            %     [minValue,minValueIndex]=min(temppossibleConfi);   %Find min value and index
            %     possibleConfi(minValueIndex)= minValue-1;
            %     possibleConfi=-sort(-possibleConfi);
            %%%%******I deleted above since I do not need to follow the possible
    TransitionMatrix(configurationsRow,configurationsRow-1) = 1- ArrivalRate;
    end % end of if condition for if the bay is empty
 %TransitionMatrix;
                 %%%+++++++++ the start of constructing possible configuration when there is an INCOMING container instead of retrieval
                 if sum(CandConfi)==rows*tiers    % this "if" loop checks if the bay is FULL
                 TransitionMatrix(configurationsRow,configurationsRow)= ArrivalRate;   % bunu artik uygulamiyoruz. ama main function da cagirdigimiz bu problari degistirdigim icin burasinin bi onemi kalmiyor.
                 else 
                 TransitionMatrix(configurationsRow,configurationsRow+1)= ArrivalRate;   
                 end
                 %%%+++++++++ the end of constructing possible configuration when there is an incoming container instead of retrieval
end
%TransitionMatrix;
end

% *********END of constructing all possible configurations for each candidate possible and calculate their transition probabilities
